// StreamUtils - github.com/bblanchon/ArduinoStreamUtils
// Copyright Benoit Blanchon 2019-2023
// MIT License

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
